var pmauth = require('../planmillapi/auth');
var Client = require('node-rest-client').Client;

var host = "https://cloud.planmill.com/acme/api/v1.5"; //replace url with real PlanMill site url with real instance name
var user = "1234"; //replace with real user id
var apikey ="oasdgha123451nkjn"; //replace with real API key
var url = "/timereports/"; //resource to be called
var resourceid = ""; //use for accessing single resource like single timereport
var intervalid = "start";
var currencyid = "EUR";


var Timereport = function(id,start,finish,comment,task, amount) {  
    this.id = id;  
    this.start = start;  
    this.finish = finish;
    this.comment = comment;
    this.task = task;
    this.amount = amount.toString();  
};

var Task = function(id,name) {  
    this.id = id;  
    this.name = name; 
};

client = new Client;

var args = {
    path: { "id": resourceid },
    parameters:{ "intervalstart":"2014-01-01T00:00:00.000+0300","intervalfinish":"2014-12-31T00:00:00.000+0300","interval":intervalid },
    headers: { "Content-Type": "application/json;charset=UTF-8", "x-PlanMill-auth": pmauth.calculateAuth(user,apikey), "x-PlanMill-currency": currencyid }
    }; //headers are the default headers for all API requests


//exports.list is mapped to timereports.list because it is in timereports.js. Check server.js for url mapping
exports.list = function (req, res) {
    //use the appropriate client method for each http verb - here client.get is used for GET requests
    client.get(host + url + "${id}", args, function (data, response) {
        //this is Jade-mapping that maps to loop used in timereport.jade layout file
       res.render('timereport', { 'timereports': data, 'title': 'Timereports' });
    }).on('error', function (err) {
        res.send(err.request.options);
    });
};
