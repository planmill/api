var Client = require('node-rest-client').Client;
var crypto = require('crypto');

var host = "";
var user = "";
var apikey ="";
var url = "";
var resourceid = "";
var currencyid = "";

module.exports.host = host;
module.exports.user = user;
module.exports.apikey = apikey;
module.exports.url = url;
module.exports.id = resourceid;
module.exports.currencyid = currencyid;
module.exports.calculateAuth = calculateAuth;


client = new Client;

/*
 * Implement authentication: nonce, timestamp and signature for x-PlanMill-Auth header.
 */
function calculateAuth(user, apikey) {
    var auth = '';
    var nonce = randomString(8, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
    var timestamp = Math.floor(new Date().getTime() / 1000);

    //calculate hmac-sha256 using user's apikey as public secret.
    var checksum = crypto.createHmac('sha256', apikey);
    checksum.update(user + nonce + timestamp.toString());
    // base64-encode the whole signature
    var signature = checksum.digest('base64');
    // create the full authentication header with all data and signature
    auth = "user:" + user + ";nonce:" + nonce + ";timestamp:" + timestamp.toString() + ";signature:" + signature;
    return auth;
}

/*
 * random alphanumeric string to be used as nonce when calculating signature for api requests.
 */
function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}